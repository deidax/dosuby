from dosuby.src.core.domain.cache import Cache


# def test_cache():
#     cache = Cache()
#     # print(cache.cached_subdomains)
#     cached_result = cache.check_if_ip_already_found_and_return_result(ip=value.get('ip'))
#     if cached_result:
#         return cached_result.get('open_ports')