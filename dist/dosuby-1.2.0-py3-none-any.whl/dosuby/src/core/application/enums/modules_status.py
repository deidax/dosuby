
class ModuleStatus:
    ABORT = 'ABORT'